#include <stdio.h>
int main(int argc,char *argv[])
{
	printf("hello\n");
}
/* 带参数的main函数*/